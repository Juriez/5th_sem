<?php 
	final class Fruit {

	}

	class Apple extends Fruit {
		
	}
?>