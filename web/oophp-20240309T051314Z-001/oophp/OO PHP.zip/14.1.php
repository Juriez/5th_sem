<?php 
	namespace html;
	class Table {

		public function show_table() {
			echo "<h1>Hello World From The HTML Table Class</h1>";
		}
	}

	class Row {

	}

	class Column {

	}

?>