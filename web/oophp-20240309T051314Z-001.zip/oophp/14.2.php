<?php 
	namespace Furniture;
	class Table {

		public function show_table() {
			echo "<h1>Hello World From The Furniture Table Class</h1>";
		}
	}

	class Row {

	}

	class Column {

	}

?>