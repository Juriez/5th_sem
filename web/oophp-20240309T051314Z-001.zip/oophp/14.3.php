<?php 
	include '14.1.php';
	include '14.2.php';

	$table = new Html\Table();
	$table->show_table();


	$table = new Furniture\Table();
	$table->show_table();

?>